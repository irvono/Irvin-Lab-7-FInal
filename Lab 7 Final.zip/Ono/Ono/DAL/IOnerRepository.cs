﻿using Ono.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ono.DAL
{
    public interface IOnerRepository  : IDisposable
    {
        IEnumerable<Oner> GetOners();
        Oner GetOnerByID(int onerId);
        void InsertOner(Oner oner);
        void DeleteOner(int onerID);
        void UpdateOner(Oner oner);
        void Save();

    }
}
