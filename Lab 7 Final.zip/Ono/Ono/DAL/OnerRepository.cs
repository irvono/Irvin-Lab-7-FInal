﻿using Ono.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ono.DAL
{
    public class OnerRepository : IOnerRepository, IDisposable
    {
        private OnoContext context;

        public OnerRepository(OnoContext context)
        {
            this.context = context;
        }

        public IEnumerable<Oner> GetOners()
        {
            return context.Oners.ToList();
        }

        public Oner GetOnerByID(int id)
        {
            return context.Oners.Find(id);
        }

        public void InsertOner(Oner oner)
        {
            context.Oners.Add(oner);
        }

        public void DeleteOner(int onerID)
        {
            Oner oner = context.Oners.Find(onerID);
            context.Oners.Remove(oner);
        }

        public void UpdateOner(Oner oner)
        {
            context.Entry(oner).State = EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
